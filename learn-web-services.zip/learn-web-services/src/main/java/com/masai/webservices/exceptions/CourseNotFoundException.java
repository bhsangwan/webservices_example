package com.masai.webservices.exceptions;

public class CourseNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	private String msg;
	
	public CourseNotFoundException() {}

	public CourseNotFoundException(String msg) {
		super(msg);
		this.msg = msg;
	}
	
}
