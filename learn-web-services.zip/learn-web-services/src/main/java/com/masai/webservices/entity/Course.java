package com.masai.webservices.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity(name="COURSES")
public class Course {

	@Id
	@GeneratedValue
	private long id;
	
	private String instructorName;
	private String name;
	
	public Course() {}

	public Course(long id, String instructorName, String name) {
		super();
		this.id = id;
		this.instructorName = instructorName;
		this.name = name;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getInstructorName() {
		return instructorName;
	}

	public void setInstructorName(String instructorName) {
		this.instructorName = instructorName;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Course [id=" + id + ", instructorName=" + instructorName + ", name=" + name + "]";
	}
	
	
}
