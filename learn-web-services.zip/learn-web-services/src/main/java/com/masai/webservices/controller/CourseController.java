package com.masai.webservices.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.masai.webservices.entity.Course;
import com.masai.webservices.exceptions.CourseNotFoundException;
import com.masai.webservices.repository.CourseRepository;

@RestController
public class CourseController {

	@Autowired
	private CourseRepository repository;
	
	@GetMapping("/courses/{id}")
	public ResponseEntity<Course> getCourse(@PathVariable long id) {
		Optional<Course> optCourse = repository.findById(id);
		
		if(id > 99999)
			throw new RuntimeException("Course ID is invalid..!");
		
		if(optCourse.isEmpty())
			throw new CourseNotFoundException("Course not found with ID:"+id);
		
		//return optCourse.get();
		return new ResponseEntity<Course>(optCourse.get(), HttpStatus.OK);
	}
	
	/*@ExceptionHandler(RuntimeException.class)
	public ResponseEntity<String> myExceptionHandler(RuntimeException ex){
		
		return new ResponseEntity<String>(ex.getMessage(),HttpStatus.BAD_REQUEST);
	}*/
	
	@PostMapping("/courses")
	public void createNewCourse(@RequestBody Course course) {
		repository.save(course);
	}
	
	@PutMapping("/courses/{id}")
	public void updateCourse(@PathVariable long id, @RequestBody Course course) {
		repository.save(course);
	}
	
	@DeleteMapping("/courses/{id}")
	public void deleteCourse(@PathVariable long id) {
		repository.deleteById(id);
	}
	
}
