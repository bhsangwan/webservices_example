insert into COURSES (ID, INSTRUCTOR_NAME, NAME) values (1001, 'Bhavesh', 'Java Full Stack');
insert into COURSES (ID, INSTRUCTOR_NAME, NAME) values (1002, 'Ratan', 'React');
insert into COURSES (ID, INSTRUCTOR_NAME, NAME) values (1003, 'Varun', 'Angular');
insert into COURSES (ID, INSTRUCTOR_NAME, NAME) values (1004, 'Riya', 'FrontEnd');